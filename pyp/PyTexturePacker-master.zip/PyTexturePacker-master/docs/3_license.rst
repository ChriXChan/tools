=======
License
=======

The project is released under the terms of MIT License. You may find the content of the license here_, or `LICENSE.txt` inside the project directory.

.. _here: http://opensource.org/licenses/MIT
