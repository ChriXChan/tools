.. PyTexturePacker rst doc

PyTexturePacker
===============

PyTexturePacker is an open source python package to create sprite sheets or sprite atlases, released under the MIT License.

A subset of feature of TexturePacker_ has been implemented in this package.

.. _TexturePacker: https://www.codeandweb.com/texturepacker

MaxRectsBinPack algorithm is used to generate sprite sheet in this package.

Contents:

.. toctree::
   :maxdepth: 2
   :glob:

   *



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

